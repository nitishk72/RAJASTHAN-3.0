<div class="navbar-fixed ">
     <nav class="teal" role="navigation">
        <div class="nav-wrapper container">
          <a id="logo-container" href="#" class="brand-logo  white-text">Medical.tech</a>
          <ul class="right hide-on-med-and-down">
            <li><a href="<?php echo base_url('index.php/');?>"  class="waves-effect white-text">Home</a></li>
            <li><a href="<?php echo base_url('index.php/About');?>"  class="waves-effect white-text">About</a></li>
            <li><a href="<?php echo base_url('index.php/Contact');?>"  class="waves-effect white-text">Contact</a></li>
          </ul>

          <ul id="nav-mobile" class="side-nav">
            <div class="container" style="margin:15px auto;width:100%;">
                <img src="<?php echo base_url('/assets/img/defaults/profile.jpg');?>" class="img-fit" style="width:200px;height:200px;border-radius:100px;    margin: 15px 0px 0px 30px;">
            </div>
            <li><a href="<?php echo base_url('index.php/');?>"  class="waves-effect waves-teal">Home</a></li>
            <li><a href="<?php echo base_url('index.php/About');?>"  class="waves-effect waves-teal">About</a></li>
            <li><a href="<?php echo base_url('index.php/Contact');?>"  class="waves-effect waves-teal">Contact</a></li>
        </div>
      </nav>
</div>
